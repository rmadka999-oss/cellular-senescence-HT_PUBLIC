Five original AIF arrays for P2, copied unchanged from the previous v1.1.0 example distribution.
NPY files contain physical refractive-index values, not model-ready inputs. PNG files are display-only previews.
No masks, model artifacts, fixed score coefficients, conversion procedures or study settings are included.
The inference-code license does not cover these images.
